"""Custom exceptions for the MQTT client module."""


class MQTTClientError(Exception):
    """Base exception for all MQTT client errors."""


class MQTTConnectionError(MQTTClientError):
    """Raised when a connection to the broker cannot be established or is lost."""


class MQTTPublishError(MQTTClientError):
    """Raised when a message fails to publish."""


class MQTTAuthError(MQTTClientError):
    """Raised when authentication with the broker fails."""


class MQTTTimeoutError(MQTTClientError):
    """Raised when an operation exceeds its timeout."""
