"""Configuration model for MQTT broker connections."""

from __future__ import annotations

import ssl
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class MQTTConfig:
    """All settings needed to connect to an MQTT broker.

    Args:
        host: Broker hostname or IP address.
        port: Broker port. Defaults to 1883 (8883 for TLS).
        client_id: Unique client identifier. Auto-generated if empty.
        username: Optional broker username.
        password: Optional broker password.
        keepalive: Seconds between keepalive pings. Default 60.
        tls: Enable TLS/SSL. Default False.
        tls_ca_certs: Path to CA certificates file (PEM) for TLS.
        tls_certfile: Path to client certificate file (PEM) for mutual TLS.
        tls_keyfile: Path to client private key file (PEM) for mutual TLS.
        tls_insecure: Skip hostname verification (not for production). Default False.
        connect_timeout: Seconds to wait for connection. Default 10.
        publish_timeout: Seconds to wait for publish confirmation. Default 5.
        reconnect_on_failure: Auto-reconnect on unexpected disconnects. Default True.
        reconnect_delay: Seconds between reconnect attempts. Default 5.
        max_reconnect_attempts: Max reconnect tries (0 = unlimited). Default 0.
        clean_session: Start with a clean session. Default True.
        protocol: MQTT protocol version (4 = 3.1.1, 5 = 5.0). Default 4.
    """

    host: str
    port: int = 1883
    client_id: str = ""
    username: Optional[str] = None
    password: Optional[str] = None
    keepalive: int = 60
    tls: bool = False
    tls_ca_certs: Optional[str] = None
    tls_certfile: Optional[str] = None
    tls_keyfile: Optional[str] = None
    tls_insecure: bool = False
    connect_timeout: float = 10.0
    publish_timeout: float = 5.0
    reconnect_on_failure: bool = True
    reconnect_delay: float = 5.0
    max_reconnect_attempts: int = 0
    clean_session: bool = True
    protocol: int = 4  # MQTTv311
    extra_connect_kwargs: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.protocol not in (4, 5):
            raise ValueError("protocol must be 4 (MQTTv311) or 5 (MQTTv5)")
        if self.port < 1 or self.port > 65535:
            raise ValueError("port must be between 1 and 65535")
        if self.keepalive < 0:
            raise ValueError("keepalive must be non-negative")
        if self.tls and self.port == 1883:
            # Nudge devs towards the conventional TLS port
            import warnings
            warnings.warn(
                "TLS is enabled but port is 1883; consider using 8883.", stacklevel=2
            )

    def build_tls_context(self) -> Optional[ssl.SSLContext]:
        """Return an SSLContext configured from the TLS fields, or None."""
        if not self.tls:
            return None
        ctx = ssl.create_default_context(cafile=self.tls_ca_certs)
        if self.tls_certfile and self.tls_keyfile:
            ctx.load_cert_chain(self.tls_certfile, self.tls_keyfile)
        if self.tls_insecure:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        return ctx
