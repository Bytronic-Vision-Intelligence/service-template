"""Core MQTT client implementation wrapping paho-mqtt."""

from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from typing import Any, Callable, Dict, Optional, Union

import paho.mqtt.client as mqtt
from paho.mqtt.client import MQTTv311, MQTTv5

from .config import MQTTConfig
from .exceptions import (
    MQTTAuthError,
    MQTTConnectionError,
    MQTTPublishError,
    MQTTTimeoutError,
)

logger = logging.getLogger(__name__)

# paho return-code constants
_CONNACK_REFUSED_CREDENTIALS = 4
_CONNACK_REFUSED_UNAUTHORIZED = 5


class MQTTClient:
    """Thread-safe MQTT client supporting connect, publish, and context-manager usage.

    Quick-start::

        from mqtt_client import MQTTClient, MQTTConfig

        config = MQTTConfig(host="broker.example.com", port=1883)
        with MQTTClient(config) as client:
            client.publish("sensors/temp", {"value": 23.5})

    Or manage lifecycle manually::

        client = MQTTClient(config)
        client.connect()
        client.publish("alerts/critical", "disk full", qos=1)
        client.disconnect()
    """

    def __init__(self, config: MQTTConfig) -> None:
        self._config = config
        self._client_id = config.client_id or f"mqtt-client-{uuid.uuid4().hex[:8]}"
        self._connected = threading.Event()
        self._connect_error: Optional[Exception] = None
        self._reconnect_count = 0
        self._lock = threading.Lock()

        protocol = MQTTv311 if config.protocol == 4 else MQTTv5
        self._client = mqtt.Client(
            client_id=self._client_id,
            clean_session=config.clean_session,
            protocol=protocol,
        )

        # Auth
        if config.username is not None:
            self._client.username_pw_set(config.username, config.password)

        # TLS
        tls_ctx = config.build_tls_context()
        if tls_ctx is not None:
            self._client.tls_set_context(tls_ctx)

        # Callbacks
        self._client.on_connect = self._on_connect
        self._client.on_disconnect = self._on_disconnect
        self._client.on_publish = self._on_publish

        # User-supplied callbacks (optional)
        self._user_on_connect: Optional[Callable] = None
        self._user_on_disconnect: Optional[Callable] = None
        self._message_handlers: Dict[str, Callable] = {}   # topic pattern → handler

        self._client.on_message = self._on_message

        logger.debug("MQTTClient initialised with client_id=%s", self._client_id)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Connect to the broker and block until the connection is confirmed.

        Raises:
            MQTTConnectionError: If the broker is unreachable or refuses the client.
            MQTTAuthError: If the broker rejects the credentials.
            MQTTTimeoutError: If the connection is not confirmed within the timeout.
        """
        self._connected.clear()
        self._connect_error = None

        logger.info(
            "Connecting to %s:%d as %s",
            self._config.host,
            self._config.port,
            self._client_id,
        )

        try:
            self._client.connect(
                self._config.host,
                self._config.port,
                keepalive=self._config.keepalive,
                **self._config.extra_connect_kwargs,
            )
        except OSError as exc:
            raise MQTTConnectionError(
                f"Could not reach broker at {self._config.host}:{self._config.port}: {exc}"
            ) from exc

        self._client.loop_start()

        if not self._connected.wait(timeout=self._config.connect_timeout):
            self._client.loop_stop()
            raise MQTTTimeoutError(
                f"Connection timed out after {self._config.connect_timeout}s"
            )

        if self._connect_error is not None:
            self._client.loop_stop()
            raise self._connect_error

        logger.info("Connected to %s:%d", self._config.host, self._config.port)

    def disconnect(self) -> None:
        """Gracefully disconnect from the broker."""
        logger.info("Disconnecting from broker")
        self._client.disconnect()
        self._client.loop_stop()
        self._connected.clear()

    @property
    def is_connected(self) -> bool:
        """True if the client is currently connected to the broker."""
        return self._connected.is_set()

    def publish(
        self,
        topic: str,
        payload: Union[str, bytes, dict, list, int, float, None] = None,
        qos: int = 0,
        retain: bool = False,
        wait_for_publish: bool = True,
    ) -> None:
        """Publish a payload to a topic.

        Args:
            topic: The MQTT topic string (e.g. ``"sensors/temperature"``).
            payload: Message body. Dicts and lists are serialised to JSON automatically.
                     Strings are encoded as UTF-8. ``None`` sends a zero-length message.
            qos: Quality of Service level — 0, 1, or 2. Default 0.
            retain: Ask the broker to retain the message. Default False.
            wait_for_publish: Block until the broker acknowledges delivery (QoS > 0)
                              or the message is queued (QoS 0). Default True.

        Raises:
            MQTTConnectionError: If the client is not connected.
            MQTTPublishError: If paho reports a publish error.
            MQTTTimeoutError: If ``wait_for_publish`` is True and delivery takes too long.
        """
        if not self.is_connected:
            raise MQTTConnectionError("Client is not connected — call connect() first.")

        if qos not in (0, 1, 2):
            raise ValueError("qos must be 0, 1, or 2")

        encoded = self._encode_payload(payload)

        with self._lock:
            result = self._client.publish(topic, encoded, qos=qos, retain=retain)

        if result.rc != mqtt.MQTT_ERR_SUCCESS:
            raise MQTTPublishError(
                f"Publish failed (rc={result.rc}): {mqtt.error_string(result.rc)}"
            )

        if wait_for_publish:
            try:
                result.wait_for_publish(timeout=self._config.publish_timeout)
            except RuntimeError as exc:
                raise MQTTPublishError(f"Publish error: {exc}") from exc
            except ValueError:
                # wait_for_publish raises ValueError when the publish failed
                raise MQTTPublishError(
                    f"Publish to '{topic}' was not acknowledged within "
                    f"{self._config.publish_timeout}s"
                )

        logger.debug(
            "Published to '%s' | qos=%d | retain=%s | size=%d bytes",
            topic,
            qos,
            retain,
            len(encoded) if encoded else 0,
        )

    def publish_many(
        self,
        messages: list[Dict[str, Any]],
        *,
        default_qos: int = 0,
        default_retain: bool = False,
    ) -> None:
        """Publish multiple messages in one call.

        Each item in *messages* is a dict with keys:
        - ``topic`` (required)
        - ``payload`` (optional)
        - ``qos`` (optional, overrides *default_qos*)
        - ``retain`` (optional, overrides *default_retain*)

        Example::

            client.publish_many([
                {"topic": "sensors/temp",     "payload": 23.5},
                {"topic": "sensors/humidity", "payload": 60, "qos": 1},
                {"topic": "alerts/low-battery", "payload": True, "retain": True},
            ])
        """
        for msg in messages:
            self.publish(
                topic=msg["topic"],
                payload=msg.get("payload"),
                qos=msg.get("qos", default_qos),
                retain=msg.get("retain", default_retain),
            )

    def subscribe(
        self,
        topic: str,
        handler: Callable,
        qos: int = 0,
    ) -> None:
        """Subscribe to a topic and register a message handler.

        Args:
            topic: MQTT topic filter — supports ``+`` (single-level) and ``#``
                   (multi-level) wildcards, e.g. ``"sensors/+"`` or ``"home/#"``.
            handler: Callable invoked for every matching message.
                     Signature: ``handler(topic: str, payload: str) -> None``.
            qos: Quality of Service level — 0, 1, or 2. Default 0.

        Raises:
            MQTTConnectionError: If the client is not connected.

        Example::

            client.subscribe("sensors/+", handle_sensor, qos=1)
            client.subscribe("alerts/#", handle_alert, qos=1)
        """
        if not self.is_connected:
            raise MQTTConnectionError("Client is not connected — call connect() first.")

        if qos not in (0, 1, 2):
            raise ValueError("qos must be 0, 1, or 2")

        result, _ = self._client.subscribe(topic, qos)
        if result != mqtt.MQTT_ERR_SUCCESS:
            raise MQTTConnectionError(
                f"Subscribe to '{topic}' failed (rc={result}): {mqtt.error_string(result)}"
            )

        self._message_handlers[topic] = handler
        logger.info("Subscribed to '%s' (QoS %d)", topic, qos)

    def subscribe_many(
        self,
        subscriptions: list,
        default_qos: int = 0,
    ) -> None:
        """Subscribe to multiple topics at once.

        Each item in *subscriptions* is a dict with keys:
        - ``topic`` (required)
        - ``handler`` (required) — callable with signature ``(topic, payload) -> None``
        - ``qos`` (optional, overrides *default_qos*)

        Example::

            client.subscribe_many([
                {"topic": "sensors/+",  "handler": handle_sensor, "qos": 1},
                {"topic": "alerts/#",   "handler": handle_alert,  "qos": 1},
                {"topic": "heartbeat",  "handler": handle_hb},
            ])
        """
        for sub in subscriptions:
            self.subscribe(
                topic=sub["topic"],
                handler=sub["handler"],
                qos=sub.get("qos", default_qos),
            )

    def listen(self) -> None:
        """Block forever, dispatching incoming messages to registered handlers.

        Call this after :meth:`connect` and :meth:`subscribe` to keep the
        process alive.  Press Ctrl-C or call :meth:`disconnect` from another
        thread to stop.
        """
        logger.info("Listening for messages — press Ctrl-C to stop")
        try:
            while self.is_connected:
                time.sleep(0.1)
        except KeyboardInterrupt:
            logger.info("KeyboardInterrupt received")
        finally:
            self.disconnect()

    # ------------------------------------------------------------------
    # Callback registration
    # ------------------------------------------------------------------

    def on_connect(self, func: Callable) -> Callable:
        """Decorator / setter to register a user-defined on-connect callback."""
        self._user_on_connect = func
        return func

    def on_disconnect(self, func: Callable) -> Callable:
        """Decorator / setter to register a user-defined on-disconnect callback."""
        self._user_on_disconnect = func
        return func

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "MQTTClient":
        self.connect()
        return self

    def __exit__(self, *_: Any) -> None:
        self.disconnect()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _encode_payload(payload: Any) -> Optional[bytes]:
        if payload is None:
            return None
        if isinstance(payload, bytes):
            return payload
        if isinstance(payload, (dict, list)):
            return json.dumps(payload, separators=(",", ":")).encode("utf-8")
        if isinstance(payload, str):
            return payload.encode("utf-8")
        # int, float, bool → string representation
        return str(payload).encode("utf-8")

    # ------------------------------------------------------------------
    # paho callbacks
    # ------------------------------------------------------------------

    def _on_connect(self, client: mqtt.Client, userdata: Any, flags: dict, rc: int, *args: Any) -> None:
        if rc == 0:
            self._reconnect_count = 0
            self._connected.set()
            logger.debug("on_connect: rc=0 (success)")
        elif rc in (_CONNACK_REFUSED_CREDENTIALS, _CONNACK_REFUSED_UNAUTHORIZED):
            self._connect_error = MQTTAuthError(
                f"Broker refused credentials (rc={rc})"
            )
            self._connected.set()  # unblock connect()
        else:
            self._connect_error = MQTTConnectionError(
                f"Broker rejected connection (rc={rc}): {mqtt.connack_string(rc)}"
            )
            self._connected.set()

        if self._user_on_connect:
            try:
                self._user_on_connect(rc)
            except Exception:
                logger.exception("Exception in user on_connect callback")

    def _on_disconnect(self, client: mqtt.Client, userdata: Any, rc: int, *args: Any) -> None:
        self._connected.clear()
        if rc != 0:
            logger.warning("Unexpected disconnect (rc=%d)", rc)
            if self._config.reconnect_on_failure:
                self._schedule_reconnect()
        else:
            logger.info("Clean disconnect")

        if self._user_on_disconnect:
            try:
                self._user_on_disconnect(rc)
            except Exception:
                logger.exception("Exception in user on_disconnect callback")

    def _on_publish(self, client: mqtt.Client, userdata: Any, mid: int) -> None:
        logger.debug("Publish confirmed: mid=%d", mid)

    def _on_message(self, client: mqtt.Client, userdata: Any, msg: mqtt.MQTTMessage) -> None:
        topic = msg.topic
        try:
            payload = msg.payload.decode("utf-8")
        except UnicodeDecodeError:
            payload = msg.payload  # keep as bytes if not UTF-8

        logger.debug("Message received on '%s'", topic)

        matched = False
        for pattern, handler in self._message_handlers.items():
            if self._topic_matches(pattern, topic):
                matched = True
                try:
                    handler(topic, payload)
                except Exception:
                    logger.exception("Exception in handler for '%s'", pattern)

        if not matched:
            logger.debug("No handler registered for topic '%s'", topic)

    @staticmethod
    def _topic_matches(pattern: str, topic: str) -> bool:
        """Return True if *topic* matches the MQTT *pattern* (supports + and #)."""
        pattern_parts = pattern.split("/")
        topic_parts   = topic.split("/")

        for i, part in enumerate(pattern_parts):
            if part == "#":
                return True          # matches everything remaining
            if i >= len(topic_parts):
                return False
            if part != "+" and part != topic_parts[i]:
                return False

        return len(pattern_parts) == len(topic_parts)

    def _schedule_reconnect(self) -> None:
        max_attempts = self._config.max_reconnect_attempts
        if max_attempts and self._reconnect_count >= max_attempts:
            logger.error(
                "Max reconnect attempts (%d) reached — giving up", max_attempts
            )
            return

        self._reconnect_count += 1
        delay = self._config.reconnect_delay
        logger.info(
            "Reconnecting in %.1fs (attempt %d)…", delay, self._reconnect_count
        )

        def _attempt():
            time.sleep(delay)
            try:
                self.connect()
            except Exception as exc:
                logger.warning("Reconnect attempt %d failed: %s", self._reconnect_count, exc)
                self._schedule_reconnect()

        threading.Thread(target=_attempt, daemon=True, name="mqtt-reconnect").start()
