"""mqtt_client - A simple, robust MQTT client for publishing payloads to topics."""

from .client import MQTTClient
from .config import MQTTConfig
from .exceptions import (
    MQTTClientError,
    MQTTConnectionError,
    MQTTPublishError,
    MQTTAuthError,
    MQTTTimeoutError,
)

__version__ = "1.1.0"
__all__ = [
    "MQTTClient",
    "MQTTConfig",
    "MQTTClientError",
    "MQTTConnectionError",
    "MQTTPublishError",
    "MQTTAuthError",
    "MQTTTimeoutError",
]
